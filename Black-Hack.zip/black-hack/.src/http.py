import socket
CEND      = '\33[0m'
CBOLD     = '\33[1m'
CITALIC   = '\33[3m'
CURL      = '\33[4m'
CBLINK    = '\33[5m'
CBLINK2   = '\33[6m'
CSELECTED = '\33[7m'
CBLACK  = '\33[30m'
CRED    = '\33[31m'
CGREEN  = '\33[32m'
CYELLOW = '\33[33m'
CBLUE   = '\33[34m'
CVIOLET = '\33[35m'
CBEIGE  = '\33[36m'
CWHITE  = '\33[37m'
CBLACKBG  = '\33[40m'
CREDBG    = '\33[41m'
CGREENBG  = '\33[42m'
CYELLOWBG = '\33[43m'
CBLUEBG   = '\33[44m'
CVIOLETBG = '\33[45m'
CBEIGEBG  = '\33[46m'
CWHITEBG  = '\33[47m'
CGREY    = '\33[90m'
CRED2    = '\33[91m'
CGREEN2  = '\33[92m'
CYELLOW2 = '\33[93m'
CBLUE2   = '\33[94m'
CVIOLET2 = '\33[95m'
CBEIGE2  = '\33[96m'
CWHITE2  = '\33[97m'
CGREYBG    = '\33[100m'
CREDBG2    = '\33[101m'
CGREENBG2  = '\33[102m'
CYELLOWBG2 = '\33[103m'
CBLUEBG2   = '\33[104m'
CVIOLETBG2 = '\33[105m'
CBEIGEBG2  = '\33[106m'
CWHITEBG2  = '\33[107m'
banner = CGREEN+'''
 __       __                 __            __                     __       
[  |     [  |               [  |  _       [  |                   [  |  _   
 | |.--.  | |  ,--.   .---.  | | / ]______ | |--.   ,--.   .---.  | | / ]  
 | '/'`\ \| | `'_\ : / /'`\] | '' <|______|| .-. | `'_\ : / /'`\] | '' <   
 |  \__/ || | // | |,| \__.  | |`\ \       | | | | // | |,| \__.  | |`\ \  
[__;.__.'[___]\'-;__/'.___.'[__|  \_]     [___]|__]\'-;__/'.___.'[__|  \_] 

''' + CEND
print banner
s=socket.socket(socket.PF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0800))

while True:
 sofi=s.recvfrom(65565)
 try:
  if "HTTP" in sofi[0][54:]:
    print CBLUE+'='*30+CEND
    sofi2=sofi[0][54:]
    if "\r\n\r\n" in sofi2:
     line=sofi2.split('\r\n\r\n')[0]
     print CRED+"http info connected :)"+CEND
     print CRED+"coded by sofi"+CEND
     print CGREEN+line[line.find('HTTP'):]+CEND
    else:
     print raw
  else:
   #print '[{}]'.format(sofi)
   pass
 except:
  pass
