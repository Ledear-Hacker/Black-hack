echo 'installing ...... '
pip2 install itertools
pip2 install subprocess
pip2 install socket
pip2 install mechanize
pip2 install requests
pip2 install cookielib
pip2 install google
pip2 install re
pip2 install urllib2
pip2 install urllib
pip2 install smtplib
pip2 install sys
pip2 install os
echo 'install scuss :)'
