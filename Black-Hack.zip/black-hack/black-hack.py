import os
import sys
info = '''
1 : SQL FINDER
2 : FACEBOOK BRUTEFORCE ATTACK
3 : HTTP SNNIFER  (root)
4 : HACKING GMAIL
5 : HCKING HOTMIL
6 : HACKING YAHOO
7 : FACEBOOK NUMBER VUN
8 : DOS ATTACK
9 : OPEN SOME PORT
10 : SPAMMER (GMAIL)
11 : CHECK PORT
12 : WORDLIST GENERATE
13 : ADMIN FINDER
14 : EXIT
'''
CEND      = '\33[0m'
CBOLD     = '\33[1m'
CITALIC   = '\33[3m'
CURL      = '\33[4m'
CBLINK    = '\33[5m'
CBLINK2   = '\33[6m'
CSELECTED = '\33[7m'
CBLACK  = '\33[30m'
CRED    = '\33[31m'
CGREEN  = '\33[32m'
CYELLOW = '\33[33m'
CBLUE   = '\33[34m'
CVIOLET = '\33[35m'
CBEIGE  = '\33[36m'
CWHITE  = '\33[37m'
CBLACKBG  = '\33[40m'
CREDBG    = '\33[41m'
CGREENBG  = '\33[42m'
CYELLOWBG = '\33[43m'
CBLUEBG   = '\33[44m'
CVIOLETBG = '\33[45m'
CBEIGEBG  = '\33[46m'
CWHITEBG  = '\33[47m'
CGREY    = '\33[90m'
CRED2    = '\33[91m'
CGREEN2  = '\33[92m'
CYELLOW2 = '\33[93m'
CBLUE2   = '\33[94m'
CVIOLET2 = '\33[95m'
CBEIGE2  = '\33[96m'
CWHITE2  = '\33[97m'
CGREYBG    = '\33[100m'
CREDBG2    = '\33[101m'
CGREENBG2  = '\33[102m'
CYELLOWBG2 = '\33[103m'
CBLUEBG2   = '\33[104m'
os.system('bash .logo.sh')
print CYELLOW+info+CEND
select = raw_input(CGREEN+'====> '+CEND)
if select == '1':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 py.py')
elif select == '2':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 fb.py')
elif select == '3':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 http.py')
elif select == '4':
    os.system('clear')
    os.chdir('.src')
    os.system('python gmail.py')
elif select == '5':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 hotmail.py')
elif select == '6':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 yahoo.py')
elif select == '7':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 fbb.py')
elif select == '8':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 dos.py')
elif select == '9':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 open-port.py')
elif select == '10':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 spammer.py')
elif select == '11':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 check-port.py')
elif select == '12':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 wd.py')
elif select == '13':
    os.system('clear')
    os.chdir('.src')
    os.system('python2 admin.py')
elif select == '14':
    os.system('clear')
    sys.exit()
else:
    print 'not found select :('
    os.system('python2 black-hack.py')
